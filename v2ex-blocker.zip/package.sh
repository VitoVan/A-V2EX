#!/bin/bash
zip v2ex-blocker *
