# Anti V2EX

Block it when you spend to much time on it.
