# Anti V2EX

Block it when you spend to much time on it.

# Install

You can download from [Chrome Web Store](https://chrome.google.com/webstore/detail/ajbjcielciekohmackgmglohckkibbdl)
Or use the zip version [Latest Release](https://github.com/VitoVan/A-V2EX/releases/latest)

# Usage

1. Set the Daily Quota (how many hours you should spend on V2EX every day).
2. Wait to be blocked.

# Screenshots

![](https://raw.githubusercontent.com/VitoVan/A-V2EX/master/screenshots/access_denied.png)
![](https://raw.githubusercontent.com/VitoVan/A-V2EX/master/screenshots/daily_quota.png)
