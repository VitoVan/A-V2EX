#!/bin/bash
zip A-V2EX *
