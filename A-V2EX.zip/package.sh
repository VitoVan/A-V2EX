#!/bin/bash
rm A-V2EX.zip
zip A-V2EX *
